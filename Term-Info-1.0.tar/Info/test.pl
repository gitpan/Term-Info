
use Term::Info;

print "This is ",Tput("bold"),"bold",Tput("sgr0")," and this is not.\n";
